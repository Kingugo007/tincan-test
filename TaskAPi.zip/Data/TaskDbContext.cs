﻿using Microsoft.EntityFrameworkCore;
using TaskManagement.APi.Model;

namespace TaskManagement.APi.Data
{
    public class TaskDbContext : DbContext
    {
        public TaskDbContext(DbContextOptions options) : base(options)
        {
           // options.Uses
        }

        public DbSet<UserTask> Tasks { get; set; } 


    }
}
