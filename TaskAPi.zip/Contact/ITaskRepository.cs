﻿using TaskManagement.APi.Dto;
using TaskManagement.APi.Model;

namespace TaskManagement.APi.Contact
{
    public interface ITaskRepository
    {
        Task<IEnumerable<UserTask>> GetAllTasks(FilterDto filter);
        Task<UserTask> GetTask(string Id);
        Task<UserTask> CreateTask(CreateTaskDto model);
        Task<UserTask> UpdateTask(UpdateTaskDto model);
        Task<bool> DeleteTask(string Id);    
    }
}
