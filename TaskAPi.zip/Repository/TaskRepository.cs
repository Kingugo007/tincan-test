﻿using Microsoft.AspNetCore.Server.IIS.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using TaskManagement.APi.Contact;
using TaskManagement.APi.Data;
using TaskManagement.APi.Dto;
using TaskManagement.APi.Model;

namespace TaskManagement.APi.Repository
{
    public class TaskRepository : ITaskRepository
    {
        private readonly ILogger<TaskRepository> _logger;
        private readonly TaskDbContext _context;
        public TaskRepository(ILogger<TaskRepository> logger, TaskDbContext context)
        {
            _logger = logger;
            _context = context;
        }
        public async Task<UserTask> CreateTask(CreateTaskDto model)
        {
            try
            {
                if (!string.IsNullOrEmpty(model.Title))
                    throw new ArgumentNullException(nameof(model.Title));
                if (string.IsNullOrEmpty(model.Description))
                    throw new ArgumentNullException(model.Description);
                if(model.DueDate < DateTime.MinValue)
                    throw new ArgumentNullException(nameof(model.DueDate));

                UserTask task = new UserTask
                {
                    Description = model.Description,
                    Title = model.Title,
                    DueDate = model.DueDate
                };

                await _context.Tasks.AddAsync(task);    
                await _context.SaveChangesAsync();  

                return task;                         
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                return null;
            }
        }

        public async Task<bool> DeleteTask(string Id)
        {
            try
            {
                var task = await _context.Tasks.FirstOrDefaultAsync(x => x.Id == Id);
                if (task is null)
                    throw new KeyNotFoundException();

                task.IsDeleted = true;

                _context.Tasks.Update(task);
                await _context.SaveChangesAsync();

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                return false;
            }

        }

        public async Task<IEnumerable<UserTask>> GetAllTasks(FilterDto filter)
        {
            try
            {
                var tasks = await _context.Tasks.Where(x => x.DueDate == filter.DueDate && x.IsCompleted == filter.IsCompleted).ToListAsync();
                return tasks;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                return new List<UserTask>();    
            }       
        }

        public async Task<UserTask> GetTask(string Id)
        {
            try
            {
                var task = await _context.Tasks.Where(x => x.Id == Id).FirstOrDefaultAsync();
                return task;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                return null;
            }
        }

        public async Task<UserTask> UpdateTask(UpdateTaskDto model)
        {
            try
            {
                if (!string.IsNullOrEmpty(model.Title))
                    throw new ArgumentNullException(nameof(model.Title));
                if (string.IsNullOrEmpty(model.Description))
                    throw new ArgumentNullException(model.Description);
                if (model.DueDate < DateTime.MinValue)
                    throw new ArgumentNullException(nameof(model.DueDate));


                var task = await _context.Tasks.FirstOrDefaultAsync(x => x.Id == model.TaskId);
                if (task is null)
                    throw new KeyNotFoundException();


                task.Description = model.Description;
                task.Title = model.Title;
                task.DueDate = model.DueDate;
                task.DateUpdated = DateTime.UtcNow;

                _context.Tasks.Update(task);
                await _context.SaveChangesAsync();

                return task;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                return null;
            }
        }
    }
}
