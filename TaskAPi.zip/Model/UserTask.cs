﻿using Microsoft.AspNetCore.Http.HttpResults;
using System.ComponentModel.DataAnnotations;

namespace TaskManagement.APi.Model
{
    public class UserTask
    {
        [Key]
        public string Id { get; set; }  = Guid.NewGuid().ToString();    
        public string Title { get; set; }   
        public string Description { get; set; } 
        public DateTime DueDate { get; set; }   
        public bool IsCompleted { get; set; }       
        public bool IsDeleted { get; set; }
        public DateTime DateCreated { get; set; } = DateTime.UtcNow;
        public DateTime DateUpdated { get; set; }   
    }
}

