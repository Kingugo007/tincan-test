﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaskManagement.APi.Contact;
using TaskManagement.APi.Dto;

namespace TaskManagement.APi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TasksController : ControllerBase
    {
        private readonly ITaskRepository _task;

        public TasksController(ITaskRepository task)
        {
            _task = task;
        }


        [HttpPost("/create-task")]
        public async Task<IActionResult> CreateTasks([FromBody] CreateTaskDto model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState.Values.SelectMany(x => x.Errors));
            var result = await _task.CreateTask(model);
            if (result is null)
                return BadRequest("Unaable to create task, Please try again!");
            return Ok(result);  
        }

        [HttpDelete("/delete-task/{Id}")]
        public async Task<IActionResult> DeleteTask(string Id)
        {
            var result =await  _task.DeleteTask(Id);
            return Ok(result);
        }


        [HttpGet("/getTasks")]
        public async Task<IActionResult> GetAllTasks([FromQuery]FilterDto filter)
        {
            var result = _task.GetAllTasks(filter);
            return Ok(result);      
        }

        [HttpGet("/getTask/{id}")]
        public async Task<IActionResult> GetAllTasks(string id)
        {
            var result = _task.GetTask(id);
            return Ok(result);
        }

        [HttpPost("/update-task")]
        public async Task<IActionResult> UpdateTasks([FromBody] UpdateTaskDto model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState.Values.SelectMany(x => x.Errors));
            var result = await _task.UpdateTask(model);
            if (result is null)
                return BadRequest("Unaable to update task, Please try again!");
            return Ok(result);
        }
    }
}
